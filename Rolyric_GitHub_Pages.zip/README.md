# Rolyric — Busca & Divisor

Aplicação web estática para pesquisar letras, remover repetições e dividir a música em slides.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie **`index.html`** para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde a publicação.
7. Abra a URL do GitHub Pages exibida pelo GitHub.

### Estrutura mínima

```text
rolyric/
├── index.html
├── .nojekyll
└── README.md
```

## Pesquisa

O Rolyric usa o **Letras.mus.br como fonte principal**. Como uma página hospedada no GitHub Pages não pode simplesmente ler o HTML de outro domínio quando o servidor não libera CORS, o código usa uma tentativa direta curta e, quando necessário, um proxy público como fallback. Isso é diferente de hospedar um servidor próprio.

A pesquisa foi otimizada para:

- tentar primeiro a URL provável `artista/música`;
- consultar a busca do Letras somente se essa tentativa falhar;
- abrir apenas a melhor candidata encontrada;
- limitar o tempo das requisições;
- evitar várias requisições simultâneas no celular.

## Observação importante

O GitHub Pages hospeda somente arquivos estáticos. Portanto, ele não funciona como um backend/proxy próprio. O funcionamento da busca depende da disponibilidade do Letras e dos serviços externos usados para contornar CORS.

Se você quiser uma versão mais estável para produção, a próxima evolução é colocar um pequeno backend/proxy próprio (por exemplo, Cloudflare Worker) e deixar o GitHub Pages somente como interface.
